# dckslks
adding on adhs functions for apple
