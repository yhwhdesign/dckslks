/* import { a2hs } from "/a2hsm.js"; */
var a2hs = require('a2hsm.js');

/**
 * Advanced (with your config) init
 */

a2hs();