/**
 * Import a2hs.js
 */
import AddToHomeScreen from "../../";

/**
 * settings
 */
AddToHomeScreen({
  brandName: "Demo"
  // ... see full list of config options below
});
